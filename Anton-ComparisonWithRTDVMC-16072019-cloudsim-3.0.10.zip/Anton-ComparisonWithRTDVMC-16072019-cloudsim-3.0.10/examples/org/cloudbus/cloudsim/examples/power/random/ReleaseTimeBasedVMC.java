package org.cloudbus.cloudsim.examples.power.random;

import java.io.IOException;
import org.cloudbus.cloudsim.PrintInFile;

/*
@author Md Anit Khan
* @since Oct 3, 2017
*/

public class ReleaseTimeBasedVMC 
{

	public static void main(String[] args) throws IOException 
	{
		boolean enableOutput = true;
		boolean outputToFile = false;
		String inputFolder = "";
		String outputFolder = "";
		String workload = "random"; // Random workload
		String vmAllocationPolicy = "thr"; // Static Threshold (THR) VM allocation policy
		String vmSelectionPolicy = "mmt"; // Minimum Migration Time (MMT) VM selection policy
		String parameter = "0.8"; // the static utilization threshold

		//I added it to print in a File: now a PrintWriter object is created
		//PrintInFile printInFile = new PrintInFile(); //I added it: now a PrintWriter object is created
		
		new RandomRunner(
				enableOutput,
				outputToFile,
				inputFolder,
				outputFolder,
				workload,
				vmAllocationPolicy,
				vmSelectionPolicy,
				parameter);
		// TODO Auto-generated method stub
	
	}
	
}
